﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using zh3_akos.Models;

namespace zh3_akos
{
    
    public partial class TermekekUc : UserControl
    {
        Zh3Context zh3Context = new Zh3Context();
        public TermekekUc()
        {
            InitializeComponent();
        }
    }
}
